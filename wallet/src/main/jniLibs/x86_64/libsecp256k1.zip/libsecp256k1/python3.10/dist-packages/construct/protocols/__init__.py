"""
protocols - a collection of network protocols
unlike the formats package, protocols convey information between two sides
"""
